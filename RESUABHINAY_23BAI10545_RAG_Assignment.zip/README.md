# HelpDeskManagement

Help Desk Ticket Management System built using ASP.NET Core Web API, ASP.NET Core MVC, Entity Framework Core, SQL Server / SQLite, Repository Pattern, xUnit, and Moq.

## Solution Architecture

This solution follows a clean 3-tier architecture with full decoupling between Web API, MVC client, and Data layers:

- **`HelpDesk.Api`**: ASP.NET Core 8 Web API implementing RESTful endpoints, Entity Framework Core, DbContext, and Repository Pattern (`ITicketRepository`, `TicketRepository`).
- **`HelpDesk.Mvc`**: ASP.NET Core 8 MVC Web Application consuming `HelpDesk.Api` endpoints via `TicketService` (`HttpClient`). Direct database access is strictly isolated from the MVC project.
- **`HelpDesk.Tests`**: xUnit Test project validating `TicketController` endpoints using **Moq** to mock the repository layer without connecting to SQL database.

---

## Ticket Entity Model

| Property Name | Data Type | Description |
| :--- | :--- | :--- |
| `Id` | `int` | Primary Key (Auto-incremented) |
| `Title` | `string` | Brief description of support request |
| `Description` | `string` | Detailed explanation of technical issue |
| `Priority` | `string` | Priority Level (`Low`, `Medium`, `High`) |
| `Status` | `string` | Ticket Status (`Open`, `In Progress`, `Closed`) |
| `RaisedBy` | `string` | Name or ID of employee raising ticket |
| `CreatedDate` | `DateTime` | Timestamp ticket was created |

---

## API Endpoints (`HelpDesk.Api`)

| HTTP Method | API Endpoint URL | Description |
| :--- | :--- | :--- |
| `GET` | `/api/Ticket/All` | Get all support tickets |
| `GET` | `/api/Ticket/{id}` | Get ticket details by ID |
| `POST` | `/api/Ticket` | Create a new support ticket |
| `PUT` | `/api/Ticket/{id}` | Update an existing ticket |
| `DELETE` | `/api/Ticket/{id}` | Delete a ticket |
| `GET` | `/api/Ticket/Status/{status}` | Get tickets filtered by status |

---

## MVC UI Features (`HelpDesk.Mvc`)

- **Dashboard**: Real-time counter statistics for Total Tickets, Open Tickets, In Progress, and Closed Tickets.
- **View All Tickets**: Interactive table of all support requests with badge styling for Status and Priority.
- **View Ticket Details**: Detailed view of ticket metadata and issue description.
- **Raise New Ticket**: Creation form with Status auto-set to `Open` and Priority selected via dropdown.
- **Edit Ticket**: Form allowing updates to Title, Description, Priority dropdown, and Status dropdown (`Open`, `In Progress`, `Closed`).
- **Filter Tickets by Status**: Status filter using dropdown and quick navigation buttons (`Open`, `In Progress`, `Closed`).

---

## Unit Testing (`HelpDesk.Tests`)

Unit tests use **xUnit** and **Moq** to mock `ITicketRepository` for fast, isolated verification:
- `GetAllTickets_ReturnsOkResult_WhenTicketsExist`
- `GetTicketById_ReturnsOkResult_WhenTicketExists`
- `GetTicketById_ReturnsNotFound_WhenTicketDoesNotExist`
- `CreateTicket_ReturnsOkResult_WhenTicketIsCreatedSuccessfully`
- `CreateTicket_ReturnsBadRequest_WhenTicketIsNull`
- `GetTicketsByStatus_ReturnsOkResult_WhenMatchingTicketExist`
- `UpdateTicket_ReturnsOkResult_WhenUpdateIsSuccessful`
- `UpdateTicket_ReturnsNotFound_WhenTicketDoesNotExist`
- `DeleteTicket_ReturnsOkResult_WhenTicketIsDeletedSuccessfully`
- `DeleteTicket_ReturnsNotFound_WhenTicketDoesNotExist`

---

## How to Run

1. **Build Solution**:
   ```bash
   dotnet build HelpDeskManagement.sln
   ```

2. **Run Unit Tests**:
   ```bash
   dotnet test HelpDesk.Tests/HelpDesk.Tests.csproj
   ```

3. **Run Web API**:
   ```bash
   dotnet run --project HelpDesk.Api/HelpDesk.Api.csproj
   ```

4. **Run MVC Application**:
   ```bash
   dotnet run --project HelpDesk.Mvc/HelpDesk.Mvc.csproj
   ```
